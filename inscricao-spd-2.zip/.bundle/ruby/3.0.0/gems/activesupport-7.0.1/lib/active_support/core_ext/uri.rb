# frozen_string_literal: true

ActiveSupport::Deprecation.warn(<<-MSG.squish)
  `active_support/core_ext/uri` is deprecated and will be removed in Rails 7.1.
MSG
