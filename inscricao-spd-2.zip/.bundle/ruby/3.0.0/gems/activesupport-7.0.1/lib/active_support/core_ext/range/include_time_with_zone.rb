# frozen_string_literal: true

# frozen_string_literal: true

ActiveSupport::Deprecation.warn(<<-MSG.squish)
  `active_support/core_ext/range/include_time_with_zone` is deprecated and will be removed in Rails 7.1.
MSG
