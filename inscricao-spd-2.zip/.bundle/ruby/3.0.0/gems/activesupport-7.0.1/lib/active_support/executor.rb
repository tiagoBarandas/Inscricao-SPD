# frozen_string_literal: true

require "active_support/execution_wrapper"

module ActiveSupport
  class Executor < ExecutionWrapper
  end
end
