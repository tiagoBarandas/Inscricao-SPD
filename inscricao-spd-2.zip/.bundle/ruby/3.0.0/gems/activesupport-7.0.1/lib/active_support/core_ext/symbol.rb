# frozen_string_literal: true

require "active_support/core_ext/symbol/starts_ends_with"
