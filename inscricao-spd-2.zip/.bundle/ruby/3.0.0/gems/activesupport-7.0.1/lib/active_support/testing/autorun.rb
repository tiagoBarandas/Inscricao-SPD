# frozen_string_literal: true

gem "minitest"

require "minitest"

Minitest.autorun
