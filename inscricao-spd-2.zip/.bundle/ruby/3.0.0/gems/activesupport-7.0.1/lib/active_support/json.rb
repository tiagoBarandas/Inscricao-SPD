# frozen_string_literal: true

require "active_support/json/decoding"
require "active_support/json/encoding"
